package id.ac.uin.lahuri.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemolahuriApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemolahuriApplication.class, args);
	}

}
