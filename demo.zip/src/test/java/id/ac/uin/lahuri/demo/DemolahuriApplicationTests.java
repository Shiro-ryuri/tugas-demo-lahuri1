package id.ac.uin.lahuri.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemolahuriApplicationTests {

	@Test
	void contextLoads() {
	}

}
